// $(document).ready(function() {

// 	$('.skills-btn').click(function() {
// 		$('.skills').fadeToggle("slow");
// 	});

// 	$('.back-btn').hover(function() {
// 		$('.projects').fadeToggle("slow", function() {
// 			$(this).addClass('projects-rails');
// 		});
// 	});

// });
(function() {


}).call(this);
